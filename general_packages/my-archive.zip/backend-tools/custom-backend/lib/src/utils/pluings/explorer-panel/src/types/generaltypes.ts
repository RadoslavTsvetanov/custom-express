export type WithDescription = {
    description: string;
};
