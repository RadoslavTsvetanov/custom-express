export class Cache<Entries extends Record<string, unknown>>{
    

    constructor(){}

    addEntry(){}

    invalidate(){}
}