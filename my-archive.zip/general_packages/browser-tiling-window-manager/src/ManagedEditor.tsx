import { useEffect } from "react"
import { Editor } from "./Workspace"

export const ManagedEditor: React.FC = ({})  => {
    useEffect(() => {

    })
    return <div>
        {/* <Editor state={}/> */}
    </div>
}