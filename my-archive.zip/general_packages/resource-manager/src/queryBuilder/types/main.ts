
type is<T extends unknown> = { is: T }