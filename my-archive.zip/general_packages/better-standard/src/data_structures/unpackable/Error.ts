class UnpakcableError {}
