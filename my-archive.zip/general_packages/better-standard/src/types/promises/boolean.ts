export const BPromise = Promise<boolean>; // you might think this is not that big deal but when you have a bunch of generics you are trying to cut corners whenever you can
