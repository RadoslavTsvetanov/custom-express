a wrapper backend around kafka which exposes some more goodies whch kafka does not support natively
