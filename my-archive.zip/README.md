Conventiosn for the project


# general packages
things which are used in one way or another in every package, for example the better standard library

# projects 
well its a project 

each project has a packages and app folder where the packages are supporting the app self conatined modules for example for the graphy browser extension in a packages we have the mock browser

# apps
simple projects which do not have their own subpackages 