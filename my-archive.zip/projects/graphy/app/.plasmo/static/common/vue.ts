globalThis.__VUE_OPTIONS_API__ = true
globalThis.__VUE_PROD_DEVTOOLS__ = process.env.NODE_ENV !== "production"
globalThis.__VUE_PROD_HYDRATION_MISMATCH_DETAILS__ = false
