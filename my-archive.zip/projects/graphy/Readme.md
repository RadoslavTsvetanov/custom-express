# Features

## graph for exploring your tabs in a more visual way

## manager page 

not onlyna popup view but you also have a manager page from which you can do various operations

## complex searching 

allows you to create subgroups  using complex queries (you have to all the tab metafata and using sql like syntax you can create subgroups and they are saved temporary ij a editor below so that you can persist searches)

## sharing instances
