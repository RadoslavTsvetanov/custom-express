# Created using T3 app

# Conventions

# components inside pages

if a component is only used within a single page its best to be inside directory of the current page if it is used in more than one page move it either in the parent components folder inside pages or if it is a flexible component place it inside components folder
