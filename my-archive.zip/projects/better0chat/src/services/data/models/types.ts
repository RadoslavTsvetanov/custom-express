export type ModelSettings = {
    url: string;
    name: string;
};
