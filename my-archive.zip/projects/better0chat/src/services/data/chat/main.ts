export type IChatService = {

};
