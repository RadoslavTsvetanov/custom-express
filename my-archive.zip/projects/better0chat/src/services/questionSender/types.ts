export type AiResponse = string;
