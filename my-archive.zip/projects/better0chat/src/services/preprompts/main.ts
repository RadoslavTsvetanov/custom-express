type prepromt = string


export class Preprompt{
    getPreprompts: ()
}